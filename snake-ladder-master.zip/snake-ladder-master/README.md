# Snakes and Ladders
Very simple Snake Ladder game using React JS, Redux and other technologies.


## Installation and Usage
To play the game, Just clone this repository and from inside the directory run
```
npm install
npm start
```

## General Features
- Multi Player
- Multiple difficulty levels
- Stats at the end of the game
- Random generation of snakes and ladders based on the difficulty selected.
- Dice is randomly generated on every roll.


### Have fun playing.