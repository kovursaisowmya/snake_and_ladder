
export default {
	board: {
		width: 900,
		height: 900,
	},

	tile: {
		height: 90,
		width: 90,
		margin: 30,
	},

	player: {
		height: 24,
		width: 24,
	},

};


